#!/bin/bash

rm -rf ~/.vim
rm -rf ~/.vimrc
rm -rf ~/.ycm_extra_conf.py

echo "Done!"

